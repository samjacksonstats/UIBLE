library(testthat)
library(QuickFunc)

test_check("QuickFunc")
